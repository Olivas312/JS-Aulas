alert('Quais o numeros antes e depois ?')

var numeroDigitado = Number (prompt("Qual o número escolido?"))
var numeroAntecessor = numeroDigitado - 1
var numeroSucessor = numeroDigitado + 1

alert(`O antecessor é ${numeroAntecessor} do ${numeroDigitado}, seguido de ${numeroSucessor}`)

