class Carro{
    constructor(valMarca,valModelo,valAno,valCor,valVelocidadeMaxima,valVelocidadeAtual){
        this.marca= valMarca;
        this.modelo= valModelo;
        this.ano= valAno;
        this.cor= valCor;
        this.velocidadeMaxima= valVelocidadeMaxima;
        this.velocidadeAtual = valVelocidadeAtual;
    }
    acelerar(valAcelerado){
            var acelerando = this.velocidadeAtual + valAcelerado;
            if(acelerando > 0 && acelerando <= this.velocidadeMaxima){
                return 'Voce esta indo á '+acelerando+' Km/h'
            }else if(acelerando >= this.velocidadeMaxima){
                return 'Você vai fundir o motor! Reduza a velocidade para as adequações da via!'
            }else{
                return ' Voce esta parado'
            }
         }
    
}
var carroNovo = new Carro('Toyota','Corola',1990,'Azul',200,0)